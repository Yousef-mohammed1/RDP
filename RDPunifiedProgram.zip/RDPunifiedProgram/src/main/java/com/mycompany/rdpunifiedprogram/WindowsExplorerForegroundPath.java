package com.mycompany.rdpunifiedprogram;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Locale;
import java.util.concurrent.TimeUnit;


public final class WindowsExplorerForegroundPath {

    private WindowsExplorerForegroundPath() {}

    public static boolean isWindowsOs() {
        String os = System.getProperty("os.name", "");
        return os.toLowerCase(Locale.ROOT).contains("win");
    }


    public static String probeFolderAt(int px, int py) {
        if (!isWindowsOs()) {
            return null;
        }
        return probeAllExplorerFolders();
    }


    private static String probeAllExplorerFolders() {
      
        String script = """
            try {
              $sh = New-Object -ComObject Shell.Application
              function PathOf($w) {
                $p = $null
                try { $p = $w.Document.Folder.Self.Path } catch {}
                if ([string]::IsNullOrWhiteSpace($p)) {
                  $u = $null
                  try { $u = $w.LocationURL } catch {}
                  if ($u -and ($u -like 'file:/*')) {
                    $t = $u -replace '^file:///','' -replace '^file://',''
                    $p = [uri]::UnescapeDataString(($t -replace '/','\\'))
                  }
                }
                return $p
              }
              foreach ($w in @($sh.Windows())) {
                try {
                  if ([int64]$w.HWND -ne 0) {
                    $o = PathOf $w
                    if ($o) { Write-Output ($o.TrimEnd([char]92)) }
                  }
                } catch {}
              }
            } catch {}
            """;

        byte[] utf16 = script.getBytes(StandardCharsets.UTF_16LE);
        String encoded = Base64.getEncoder().encodeToString(utf16);
        ProcessBuilder pb = new ProcessBuilder(
            "powershell.exe", "-NoProfile", "-NonInteractive", "-EncodedCommand", encoded);
        pb.redirectErrorStream(true);
        Process p;
        try {
            p = pb.start();
        } catch (Exception e) {
            return null;
        }
        StringBuilder out = new StringBuilder(256);
        try (BufferedReader r = new BufferedReader(
                new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                if (out.length() > 0) {
                    out.append('\n');
                }
                out.append(line);
            }
        } catch (Exception e) {
            p.destroyForcibly();
            return null;
        }
        try {
            if (!p.waitFor(3, TimeUnit.SECONDS)) {
                p.destroyForcibly();
                return null;
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            p.destroyForcibly();
            return null;
        }
        String result = out.toString().trim();
        return result.isEmpty() ? null : result;
    }
}