package com.mycompany.rdpunifiedprogram;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;


public final class RemoteAccessRestrictions {

    private RemoteAccessRestrictions() {}

    private static final String[] RESTRICTED_PATH_PREFIXES;

    private static final Set<String> BLOCKED_TRANSFER_EXTENSIONS;

    
    private static final Set<String> PER_USER_SENSITIVE_FOLDERS;

    static {
        
        RESTRICTED_PATH_PREFIXES = new String[] {

            // ── Core Windows system directories ──────────────────────────────
            "c:\\windows",                       
            "c:\\program files",               
            "c:\\program files (x86)",           
            "c:\\programdata",                   

            // ── Boot, recovery and partitioning ──────────────────────────────
            "c:\\boot",                          
            "c:\\recovery",                       
            "c:\\system volume information",     
            "c:\\efi",                            

            // ── Hidden OS / upgrade infrastructure ───────────────────────────
            "c:\\$recycle.bin",                   
            "c:\\$windows.~bt",                   
            "c:\\$windows.~ws",                   
            "c:\\$winreagent",                    
            "c:\\$sysreset",                      
            "c:\\msocache",                       
            "c:\\perflogs",                       
            "c:\\intel",                          
            "c:\\amd",                            
            "c:\\nvidia",                         

            // ── Shared / default user profile locations ───────────────────────
            "c:\\users\\default",                 
            "c:\\users\\all users",               
            "c:\\users\\public",                  

            // ── Drive D ───────────────────────────────────────────────────────
            "d:\\windows",
            "d:\\program files",
            "d:\\program files (x86)",
            "d:\\programdata",
            "d:\\boot",
            "d:\\recovery",
            "d:\\system volume information",
            "d:\\$recycle.bin",
            "d:\\$winreagent",
            "d:\\$sysreset",

            // ── Drive E ───────────────────────────────────────────────────────
            "e:\\windows",
            "e:\\program files",
            "e:\\program files (x86)",
            "e:\\programdata",
            "e:\\boot",
            "e:\\recovery",
            "e:\\system volume information",
            "e:\\$recycle.bin",
            "e:\\$winreagent",
            "e:\\$sysreset",
        };

        // ── Blocked file-transfer extensions ─────────────────────────────────
        Set<String> ext = new HashSet<>();
        ext.add(".exe");
        ext.add(".bat");
        ext.add(".cmd");
        ext.add(".com");
        ext.add(".msi");
        ext.add(".scr");
        ext.add(".pif");
        ext.add(".ps1");
        ext.add(".vbs");
        ext.add(".js");
        ext.add(".jse");
        ext.add(".wsf");
        ext.add(".wsh");
        ext.add(".msc");
        ext.add(".reg");
        BLOCKED_TRANSFER_EXTENSIONS = Collections.unmodifiableSet(ext);

        
        Set<String> s = new HashSet<>();
        s.add("appdata");                     
        s.add(".ssh");                        
        s.add(".gnupg");                      
        s.add(".aws");                        
        s.add(".azure");                      
        s.add(".kube");                       
        s.add(".docker");                     
        s.add(".config");                    
        s.add("credentials");                 
        s.add("saved games");                 
        s.add("searches");                    
        s.add("sendto");                      
        s.add("nethood");                     
        s.add("printhood");                   
        s.add("templates");                   
        s.add("recent");                      
        s.add("cookies");                     
        s.add("history");                     
        s.add("temporary internet files");    
        s.add("start menu");                  
        s.add("contacts");                    
        s.add("links");                       
        PER_USER_SENSITIVE_FOLDERS = Collections.unmodifiableSet(s);
    }

    public static boolean hasRestrictedExplorerFolderPolicy() {
        return RESTRICTED_PATH_PREFIXES.length > 0;
    }


    public static boolean isRestrictedExplorerFolder(String absoluteFolderPath) {
        if (pathMatchesRestrictedPrefixes(absoluteFolderPath)) {
            return true;
        }
        return isPerUserSensitivePath(absoluteFolderPath);
    }


    private static boolean isPerUserSensitivePath(String absolutePath) {
        if (absolutePath == null || absolutePath.isEmpty()) {
            return false;
        }
        String p = absolutePath.toLowerCase(Locale.ROOT).replace('/', '\\');
        
        String[] parts = p.split("\\\\");
        if (parts.length < 4 || !parts[1].equals("users")) {
            return false;
        }
        String folder = parts[3];

        
        if (PER_USER_SENSITIVE_FOLDERS.contains(folder)) {
            return true;
        }
        
        if (folder.startsWith("ntuser")) {
            return true;
        }
        
        if (folder.startsWith(".")) {
            return true;
        }
        
        if (parts.length >= 5 && folder.equals("start menu")) {
            return true; 
        }
        return false;
    }

    private static boolean pathMatchesRestrictedPrefixes(String absolutePath) {
        if (absolutePath == null || absolutePath.isEmpty()) {
            return false;
        }
        String p = absolutePath.toLowerCase(Locale.ROOT).replace('/', '\\');
        if (!p.endsWith("\\")) {
            p = p + "\\";
        }
        for (String prefix : RESTRICTED_PATH_PREFIXES) {
            String pre = prefix.toLowerCase(Locale.ROOT);
            if (!pre.endsWith("\\")) {
                pre = pre + "\\";
            }
            if (p.startsWith(pre)) {
                return true;
            }
        }
        return false;
    }

    public static boolean isBlockedTransferExtension(String filename) {
        if (filename == null) {
            return false;
        }
        int dot = filename.lastIndexOf('.');
        if (dot < 0 || dot >= filename.length() - 1) {
            return false;
        }
        String ext = filename.substring(dot).toLowerCase(Locale.ROOT);
        return BLOCKED_TRANSFER_EXTENSIONS.contains(ext);
    }

    public static boolean isBlockedOutboundPath(String canonicalAbsolutePath) {
        if (canonicalAbsolutePath == null) {
            return true;
        }
        return pathMatchesRestrictedPrefixes(canonicalAbsolutePath);
    }

    public static boolean isOutgoingFileTransferAllowed(File f) {
        if (f == null || !f.isFile() || !f.canRead()) {
            return false;
        }
        if (isBlockedTransferExtension(f.getName())) {
            return false;
        }
        try {
            String canon = f.getCanonicalPath();
            if (isBlockedOutboundPath(canon)) {
                return false;
            }
        } catch (IOException e) {
            return false;
        }
        return true;
    }

    public static boolean isIncomingTransferFilenameAllowed(String sanitizedFilename) {
        return !isBlockedTransferExtension(sanitizedFilename);
    }

    public static boolean shouldBlockRemoteKeyPress(boolean windowsMetaHeld, int keyCode) {
        if (!windowsMetaHeld) {
            return false;
        }
        return keyCode == java.awt.event.KeyEvent.VK_R;
    }

    public static boolean isWindowsMetaKeyCode(int keyCode) {
        return keyCode == java.awt.event.KeyEvent.VK_WINDOWS
            || keyCode == java.awt.event.KeyEvent.VK_META;
    }
}